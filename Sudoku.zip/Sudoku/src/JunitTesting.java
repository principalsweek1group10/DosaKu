import static org.junit.Assert.*;

import java.awt.event.ActionEvent;

import org.junit.Test;

public class JunitTesting {

	@Test
	public void test() {
		sudoku test = new sudoku();
		test.menu();
		test.difficulty();
		test.rules();
	}

}
